//  
//  AccessTokenExtractorPlugin.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import Moya
import Result

class AccessTokenExtractorPlugin: PluginType {
    
    private var keychain: KeychainServicing
    
    init(keychain: KeychainServicing) {
        self.keychain = keychain
    }
    
    func didReceive(_ result: Result<Response, MoyaError>, target: TargetType) {
        let apiService = target as! ApiService
        
        switch apiService {
		case .login,
             .refreshToken:
            
            switch result {
            case .success(let response):
                do {
                    let successfulResponse = try response.filterSuccessfulStatusCodes()
                    guard let header = successfulResponse.response?.allHeaderFields else { return }
                    guard let accessToken = header["Authorization"] as? String else { return }
                    keychain.accessToken = accessToken
                } catch {
                    print(error.localizedDescription)
                }
            case .failure: break
            }
            
        default:
            break
        }
    }
    
}
