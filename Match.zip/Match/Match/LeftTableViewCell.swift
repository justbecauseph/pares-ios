//
//  LeftTableViewCell.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import UIKit

class LeftTableViewCell: UITableViewCell,CustomCell {

    //MARKS: Outlets
    @IBOutlet weak var messageLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func configure(message: String) {
        self.messageLabel.text = message
    }

    
}
