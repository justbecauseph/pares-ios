//  
//  CongratulationsBuilder.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/14/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

class CongratulationsBuilder {
    
    static func build() -> CongratulationsViewController {
        let vc = CongratulationsViewController.createFromNib()

		let viewModel: CongratulationsViewModel = {
			let dependency = CongratulationsViewModel.Dependency()
			return CongratulationsViewModel(dependency: dependency)
		}()

		vc.viewModel = viewModel

        return vc
    }
    
}
