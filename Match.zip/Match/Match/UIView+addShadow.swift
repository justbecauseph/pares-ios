//  
//  UIView+addShadow.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

extension UIView {

	func addShadow() {
		self.layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
		self.layer.shadowRadius = 2
		self.layer.shadowOffset = .zero
		self.layer.shadowOpacity = 0.3
	}

	func addShadowAtBottom() {
		let offset: CGFloat = 0.5
		let rect = CGRect(x: 0, y: self.frame.height + offset, width: self.frame.width, height: 1)
		self.layer.shadowPath = UIBezierPath(rect: rect).cgPath
		self.layer.shadowRadius = 0.8
		self.layer.shadowOffset = .zero
		self.layer.shadowOpacity = 0.3
	}

}

