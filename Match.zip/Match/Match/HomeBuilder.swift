//  
//  HomeBuilder.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

class HomeBuilder {
    
    static func build() -> HomeViewController {
        let vc = HomeViewController.createFromNib()

		let viewModel: HomeViewModel = {
			let dependency = HomeViewModel.Dependency()
			return HomeViewModel(dependency: dependency)
		}()

		vc.viewModel = viewModel

        return vc
    }
    
}
