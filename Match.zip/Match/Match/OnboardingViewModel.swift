//  
//  OnboardingViewModel.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

protocol OnboardingViewModelInput {
//    func getElements()
}

protocol OnboardingViewModelOutput {
    var isProcessing: BehaviorRelay<Bool> { get }
    var errorMessage: BehaviorRelay<String> { get }
}

class OnboardingViewModel: OnboardingViewModelInput, OnboardingViewModelOutput {

    // MARK: - Init
    
	struct Dependency {
	}

	init(dependency: Dependency) {
		self.dependency = dependency
	}
    
    var inputs: OnboardingViewModelInput { return self }
    var outputs: OnboardingViewModelOutput { return self }
    
    // MARK: - Inputs
    
//    func getElements() {
//        isProcessing.accept(true)
//    }
    
    // MARK: - Output
    
    let isProcessing: BehaviorRelay<Bool> = BehaviorRelay(value: false)
    let errorMessage: BehaviorRelay<String> = BehaviorRelay(value: "")

	// MARK: - Private

	private var dependency: Dependency
	private var disposeBag = DisposeBag()

    // MARK: - Deinit
    
	deinit {
		print("--Deallocating \(self)")
	}

}

extension OnboardingViewModel {
    
    // { helpers }

}
