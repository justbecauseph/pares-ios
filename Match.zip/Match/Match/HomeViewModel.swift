//  
//  HomeViewModel.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

protocol HomeViewModelInput {
//    func getElements()
}

protocol HomeViewModelOutput {
    var isProcessing: BehaviorRelay<Bool> { get }
    var errorMessage: BehaviorRelay<String> { get }
}

class HomeViewModel: HomeViewModelInput, HomeViewModelOutput {

    // MARK: - Init
    
	struct Dependency {
	}

	init(dependency: Dependency) {
		self.dependency = dependency
	}
    
    var inputs: HomeViewModelInput { return self }
    var outputs: HomeViewModelOutput { return self }
    
    // MARK: - Inputs
    
//    func getElements() {
//        isProcessing.accept(true)
//    }
    
    // MARK: - Output
    
    let isProcessing: BehaviorRelay<Bool> = BehaviorRelay(value: false)
    let errorMessage: BehaviorRelay<String> = BehaviorRelay(value: "")

	// MARK: - Private

	private var dependency: Dependency
	private var disposeBag = DisposeBag()

    // MARK: - Deinit
    
	deinit {
		print("--Deallocating \(self)")
	}

}

extension HomeViewModel {
    
    // { helpers }

}
