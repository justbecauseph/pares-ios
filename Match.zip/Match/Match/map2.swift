//  
//  map2.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import Moya
import RxSwift

extension ObservableType where E == Response {

	func map2<D: Decodable>(_ decodable: D.Type) -> Observable<D> {
		return self
				.map(decodable, using: JSONDecoder.snakeToCamelcase, failsOnEmptyData: false)
				.catchError { e in

					guard let error = e as? MoyaError else {
						throw e
					}

					guard case MoyaError.objectMapping(let decodingError, _) = error else {
						throw e
					}

					let appError = BasicError(message: "\(decodingError)")
					throw appError
				}
	}

}
