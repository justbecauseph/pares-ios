//  
//  CoordinatorType.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

protocol CoordinatorType: AnyObject {

	var childCoordinators: [CoordinatorType] { get set }
	func start()

}

extension CoordinatorType {

	func add(_ childCoordinator: CoordinatorType) {
		childCoordinators.append(childCoordinator)
	}

	func remove(_ childCoordinator: CoordinatorType) {
		childCoordinators.removeAll(where: { $0 === childCoordinator })
	}

}
