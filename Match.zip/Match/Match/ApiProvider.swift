//  
//  ApiProvider.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Alamofire
import Foundation
import Moya

class ApiProvider: MoyaProvider<ApiService> {

	static let `default` = ApiProvider(stubbed: false, keychain: KeychainService())

	let keychain: KeychainServicing

	private static func defaultPlugins(usingKeychain keychain: KeychainServicing) -> [PluginType] {
		let networkLogger = NetworkLoggerPlugin(verbose: true, cURL: false)
		let authenticationPlugin = AuthenticationPlugin(keychain: keychain)
		let accessTokenExtractor = AccessTokenExtractorPlugin(keychain: keychain)
		let fcmTokenAdder = FcmTokenAdderPlugin(keychain: keychain)
		return [networkLogger, authenticationPlugin, accessTokenExtractor, fcmTokenAdder]
	}

	init(stubbed: Bool, keychain: KeychainServicing) {
		self.keychain = keychain
		let host = Config.shared.baseURL.absoluteString
		let serverTrust = ServerTrustPolicyManager(policies: [host: .disableEvaluation])
		let manager = Manager(serverTrustPolicyManager: serverTrust)
		let plugins: [PluginType] = ApiProvider.defaultPlugins(usingKeychain: keychain)
		if stubbed {
			super.init(stubClosure: MoyaProvider.immediatelyStub, manager: manager, plugins: plugins, trackInflights: true)
		} else {
			super.init(manager: manager, plugins: plugins, trackInflights: true)
		}
	}

}

