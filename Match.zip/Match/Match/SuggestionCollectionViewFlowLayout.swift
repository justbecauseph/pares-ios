//
//  SuggestionCollectionViewFlowLayout.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

class SuggestionCollectionViewFlowLayout: UICollectionViewFlowLayout {
    
    init(frame: CGRect, numberOfSuggestions: CGFloat) {
        super.init()
        self.scrollDirection = .horizontal
        self.minimumLineSpacing = 8
        self.minimumInteritemSpacing = 8
        self.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        let spacing:CGFloat = 16
        let width: CGFloat = (frame.width - spacing) / numberOfSuggestions
        let height: CGFloat = width - 80
        self.itemSize = CGSize(width: width, height: height)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
