//  
//  HomeCoordinatorCoordinator.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

protocol HomeCoordinatorCoordinatorDelegate: AnyObject {
	func dettach(_ coordinator: HomeCoordinatorCoordinator)
}


class HomeCoordinatorCoordinator: CoordinatorType {

	weak var delegate: HomeCoordinatorCoordinatorDelegate?

    var childCoordinators: [CoordinatorType] = []
	var modalSource: UIViewController
    
	init(modalSource: UIViewController) {
        self.modalSource = modalSource
    }
    
    func start() {
                
    }
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}
