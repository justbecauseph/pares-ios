//  
//  MainCoordinator.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

class MainCoordinator: CoordinatorType {

	var childCoordinators: [CoordinatorType] = []

	lazy var rootVc: HomeViewController = {
		let rootVc = HomeBuilder.build()
		rootVc.delegate = self
		return rootVc
	}()

	lazy var navigationVc: UINavigationController = {
		let navigationVc = UINavigationController(rootViewController: rootVc)
        navigationVc.isNavigationBarHidden = true
		return navigationVc
	}()

	init() {
	}

	func start() {
    }

	deinit {
		print("--Deallocating \(self)")
	}

}

extension MainCoordinator: RootViewControllerDelegate {
    func presentHome(_ vc: RootViewController) {
        
    }
    
	func dismiss(_ vc: RootViewController) {
        vc.dismiss(animated: true, completion: nil)
        
	}
}

extension MainCoordinator: OnboardingViewControllerDelegate {
    func presentLandingVc(_ vc: OnboardingViewController) {
        let homeCoordinator = HomeCoordinator(modalSource: navigationVc)
        homeCoordinator.delegate = self
        self.add(homeCoordinator)
        homeCoordinator.start()
    }
    
    func dismiss(_ vc: OnboardingViewController) {
        
    }

}

extension MainCoordinator: HomeCoordinatorDelegate {
    func dettach(_ coordinator: HomeCoordinator) {
        remove(coordinator)
    }
}

extension MainCoordinator: HomeViewControllerDelegate {
    func presentMatch(_ vc: HomeViewController) {
        let matchVc = CongratulationsBuilder.build()
        matchVc.delegate = self
        
        self.navigationVc.present(matchVc, animated: true, completion: nil)
    }
    
    func dismiss(_ vc: HomeViewController) {
        
    }
}

extension MainCoordinator: CongratulationsViewControllerDelegate {
    func dismiss(_ vc: CongratulationsViewController) {
        
    }
}
