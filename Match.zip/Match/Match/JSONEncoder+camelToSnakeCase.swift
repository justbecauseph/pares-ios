//  
//  JSONEncoder+camelToSnakeCase.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

extension JSONEncoder {
    
    static let camelToSnakeCase: JSONEncoder = {
        let encoder = JSONEncoder()
        encoder.keyEncodingStrategy = .convertToSnakeCase
        return encoder
    }()
    
}
