//  
//  CongratulationsViewModel.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/14/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import RxCocoa
import RxSwift

protocol CongratulationsViewModelInput {
//    func getElements()
}

protocol CongratulationsViewModelOutput {
    var isProcessing: BehaviorRelay<Bool> { get }
    var errorMessage: BehaviorRelay<String> { get }
}

class CongratulationsViewModel: CongratulationsViewModelInput, CongratulationsViewModelOutput {

    // MARK: - Init
    
	struct Dependency {
	}

	init(dependency: Dependency) {
		self.dependency = dependency
	}
    
    var inputs: CongratulationsViewModelInput { return self }
    var outputs: CongratulationsViewModelOutput { return self }
    
    // MARK: - Inputs
    
//    func getElements() {
//        isProcessing.accept(true)
//    }
    
    // MARK: - Output
    
    let isProcessing: BehaviorRelay<Bool> = BehaviorRelay(value: false)
    let errorMessage: BehaviorRelay<String> = BehaviorRelay(value: "")

	// MARK: - Private

	private var dependency: Dependency
	private var disposeBag = DisposeBag()

    // MARK: - Deinit
    
	deinit {
		print("--Deallocating \(self)")
	}

}

extension CongratulationsViewModel {
    
    // { helpers }

}
