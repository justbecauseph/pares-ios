//  
//  AppInitManager.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

class AppInitManager {

	private var window: UIWindow
	private var mainCoordinator: MainCoordinator

	init() {
		self.window = UIWindow(frame: UIScreen.main.bounds)
		self.mainCoordinator = MainCoordinator()
	}

}

extension AppInitManager {

	func start() {
		initFirstTimeInstall()
		initWindow()
	}

}


extension AppInitManager {

	private func initWindow() {
		window.rootViewController = mainCoordinator.navigationVc
		window.makeKeyAndVisible()
		mainCoordinator.start()
	}

	private func initFirstTimeInstall() {
		let defaults = DefaultsService()
		if !defaults.hasInitializedFreshInstall {
			let keychain = KeychainService()
			keychain.clear()
			defaults.hasInitializedFreshInstall = true
		}
	}

}
