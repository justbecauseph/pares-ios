//  
//  AuthenticationPlugin.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import Moya

class AuthenticationPlugin: PluginType {
    
    private var keychain: KeychainServicing

	// NOTE: - Update this token everytime you change projects.
	private static let basicToken = "Basic eWFtYWhhOnBSSmQ0QUVremVndA=="
    
    init(keychain: KeychainServicing) {
        self.keychain = keychain
    }
    
    func prepare(_ request: URLRequest, target: TargetType) -> URLRequest {
		let api = target as! ApiService
		var modifiedRequest = request
        if api.requiresAuthentication {
            let accessToken = keychain.accessToken.expect("Expected access token for path: \(target.path)")
            modifiedRequest.addValue(accessToken, forHTTPHeaderField: "Authorization")
		} else {
			modifiedRequest.addValue(AuthenticationPlugin.basicToken, forHTTPHeaderField: "Authorization")
		}
		return modifiedRequest
    }
    
}
