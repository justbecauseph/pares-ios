//
//  LoginResponse.swift
//  MyShoppingBox
//
//  Created by Mark D. Rufino on 05/28/2019.
//  Copyright © 2019 coreproc-inc. All rights reserved.
//

import Foundation

struct LoginResponse: Codable {
}
