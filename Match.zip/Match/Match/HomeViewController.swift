//  
//  HomeViewController.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import UIKit
import MBProgressHUD
import RxCocoa
import RxSwift



enum MessageType: String {
    case sender
    case receiver
}

protocol HomeViewControllerDelegate: AnyObject {
    func dismiss(_ vc: HomeViewController)
    func presentMatch(_ vc: HomeViewController)
    
}

class HomeViewController: UIViewController, CreatedFromNib, DisplaysProgress {
    
    weak var delegate: HomeViewControllerDelegate?
    
    // MARK: - Outlets
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var suggestionCollectionView: UICollectionView!
    
    
    // MARK: - DisplaysProgress
    
    var viewForHUD: UIView {
        return self.view
    }
    
    // MARK: - Init
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        initCollectionView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        initViewModel()
    }
    
    private func initViews() {
        initTableView()        
    }
    
    private func initTableView() {
        tableView.register(ChatTableViewCell.self)
        tableView.register(LeftTableViewCell.self)
        tableView.estimatedRowHeight = UITableView.automaticDimension
        tableView.rowHeight = UITableView.automaticDimension
        tableView.dataSource = self
        tableView.separatorStyle = .none
    }
    
    private func initCollectionView() {
        suggestionCollectionView.register(SuggestionCollectionViewCell.self)
        suggestionCollectionView.dataSource = self
        suggestionCollectionView.delegate = self
        suggestionCollectionView.showsHorizontalScrollIndicator = false
        DispatchQueue.main.async {
            self.suggestionCollectionView.collectionViewLayout = SuggestionCollectionViewFlowLayout(frame: self.suggestionCollectionView.frame, numberOfSuggestions: CGFloat(self.suggestions.count))
        }
    }
    
    // MARK: - ViewModel
    
    var viewModel: HomeViewModel!
    
    private func initViewModel() {
        bindInputs()
        bindOutputs()
    }
    
    private func bindInputs() {
        
    }
    
    private func bindOutputs() {
        
        viewModel
            .outputs
            .isProcessing
            .asDriver()
            .drive(onNext: { [unowned self] (isProcessing) in
                if isProcessing {
                    self.showProgress()
                } else {
                    self.hideProgress()
                }
            }).disposed(by: disposeBag)
        
        viewModel
            .outputs
            .errorMessage
            .asDriver()
            .filter { !$0.isEmpty }
            .drive(onNext: { [unowned self] (errorMessage) in
                self.showAlert(type: .error, title: nil, message: errorMessage)
            }).disposed(by: disposeBag)
        
    }
    
    // MARK: - Private
    
    private var disposeBag = DisposeBag()
    
    private var blurbs = ["Wazzup boi, sorry been busy these days but now i think i have time for you lol", "I've heard from my friends that you're looking for dates hmmm let me help ya ;)", "Or i was mistaken? Hahahaha forgive me for trying to be cheeky but i'm just here for you pare!", "In any case, you came to me first pare, and i can pretty much assume that you'd want to be with someone you can rely on for a long time!", "I might not know a few things about you, but you can share it naman with me pare!", "Or if you want pare chong, i can arrange something based from the people in you area nearby! ;)", "Anyways, I'm going to hit you up later to ask more about yourself so i can give you better matches :D", "See yah!", "Good Morning Pare! Tara Kape?"]
    private var suggestions = ["Tara pare!", "Pass muna ko😞", "Juice nalang!"]
    private var counter = 0
    
    // MARK: - Deinit
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}

extension HomeViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return blurbs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row % 2 == 0 {
            let cell = tableView.dequeue(ChatTableViewCell.self, for: indexPath)
            cell.configure(message: self.blurbs[indexPath.row])
            cell.selectionStyle = .none
            return cell
        }else if indexPath.row <= 7 {
            let cell = tableView.dequeue(ChatTableViewCell.self, for: indexPath)
            cell.configure(message: self.blurbs[indexPath.row])
            cell.selectionStyle = .none
            return cell
        }else {
            let cell = tableView.dequeue(LeftTableViewCell.self, for: indexPath)
            cell.configure(message: self.blurbs[indexPath.row])
            cell.selectionStyle = .none
            return cell
        }
    }
    
    
}

//Extension for dataSource of the collectionView
extension HomeViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return suggestions.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = suggestionCollectionView.dequeue(SuggestionCollectionViewCell.self, for: indexPath)
        
        cell.configure(label: self.suggestions[indexPath.row])
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        counter += 1
        
        if counter == 5 {
            if indexPath.row == 0 {
                self.delegate?.presentMatch(self)
            }else {
                //Proceed with altering the questions
                self.setUpData(index: indexPath.row)
            }
        }else {
            self.setUpData(index: indexPath.row)
        }
    }
    
}

extension HomeViewController {
    
    func alterSuggestionsAndAnswers() {
        switch counter {
        case 1:
             self.blurbs.append("Where is your favorite spot or place?")
             self.suggestions.append("Makati")
             self.suggestions.append("Pasig")             
        case 2:
            self.blurbs.append("What is your favorite food Chong! Pare!?")
            self.suggestions.append("Cake")
            self.suggestions.append("Pasta")
            self.suggestions.append("🍕")
        case 3:
            self.blurbs.append("How old are you pare?")
            self.suggestions.append("18 - 25")
            self.suggestions.append("25 - 35")
            self.suggestions.append("36 - above")
        case 4:
            self.blurbs.append("Uyyy may ka match ka na!!!")
            self.suggestions.append("See match <3")
            self.suggestions.append("Nah! Ask me more")
        default: break
        }
    }
    
    func setUpData(index: Int) {
        self.blurbs.append(self.suggestions[index])
        
        self.suggestions.removeAll()
        
        self.alterSuggestionsAndAnswers()
        self.tableView.reloadData()
        self.suggestionCollectionView.reloadData()
    }
}

