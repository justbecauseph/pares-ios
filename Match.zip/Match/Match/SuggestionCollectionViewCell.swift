//
//  SuggestionCollectionViewCell.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import UIKit

class SuggestionCollectionViewCell: UICollectionViewCell, CustomCell {

    
    @IBOutlet weak var suggestionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }

    func configure(label: String) {
        self.suggestionLabel.text = label
    }
    
}
