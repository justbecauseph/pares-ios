//  
//  ApiError.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

enum CustomErrorMessageType: Decodable {

	case string(String)
	case dict([String: [String]])

	init(from decoder: Decoder) throws {
		let container = try decoder.singleValueContainer()
		do {
			self = try .string(container.decode(String.self))
		} catch DecodingError.typeMismatch {
			self = try .dict(container.decode([String: [String]].self))
		}
	}

}

struct CustomError: Decodable {
	let code: String?
	let httpCode: Int?
	var message: String?
	var errors: CustomErrorMessageType?
}

struct ApiError: Decodable {
	
	var message: String?
	var error: CustomError?

	init(message: String) {
		self.message = message
	}

	func getErrorMessage() -> String {
		if let customErrors = self.error?.errors {
			switch customErrors {
			case .string(let message):
				return message
			case .dict(let dictMessages):
				var lines: [String] = []
				for (key, values) in dictMessages {
					lines.append(key.uppercased())
					for value in values { lines.append("• \(value)") }
					lines.append("\n")
				}
				return lines.joined(separator: "\n")
			}
		}
		if let apiErrorMessage = self.error?.message {
			return apiErrorMessage
		}
		guard message != nil else {
			let errorBody = """
			Unable to parse error body:
			\(dump(self))
			"""
			return errorBody
		}
		return self.message ?? ""
	}

}

extension ApiError: Swift.Error, LocalizedError {
	var errorDescription: String? {
		return self.getErrorMessage()
	}
}
