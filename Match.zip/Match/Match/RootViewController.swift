//  
//  RootViewController.swift
//  Sample7
//
//  Created by Mark D. Rufino on 05/30/2019.
//  Copyright © 2019 coreproc-inc. All rights reserved.
//

import UIKit
import MBProgressHUD
import RxCocoa
import RxSwift

protocol RootViewControllerDelegate: AnyObject {
    func dismiss(_ vc: RootViewController)
    func presentHome(_ vc: RootViewController)
}

class RootViewController: UIViewController, CreatedFromNib, DisplaysProgress {
    
    weak var delegate: RootViewControllerDelegate?
    
    // MARK: - Outlets
    @IBOutlet weak var datingButton: UIButton!
    
    // MARK: - DisplaysProgress
    
    var viewForHUD: UIView {
        return self.view
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        initViewModel()
    }
    
    private func initViews() {
        
    }
    
    // MARK: - ViewModel
    
    var viewModel: RootViewModel!
    
    private func initViewModel() {
        bindInputs()
        bindOutputs()
        bindButtonActions()
    }
    
    private func bindInputs() {
        
    }
    
    private func bindOutputs() {
        
        viewModel
            .outputs
            .isProcessing
            .asDriver()
            .drive(onNext: { [unowned self] (isProcessing) in
                if isProcessing {
                    self.showProgress()
                } else {
                    self.hideProgress()
                }
            }).disposed(by: disposeBag)
        
        viewModel
            .outputs
            .errorMessage
            .asDriver()
            .filter { !$0.isEmpty }
            .drive(onNext: { [unowned self] (errorMessage) in
                // { }
            }).disposed(by: disposeBag)
        
    }
    
    private func bindButtonActions() {
        datingButton
            .rx
            .tap
            .subscribe(onNext: { [unowned self] _ in
                //TODO inserting delegate for the home view
            }).disposed(by: disposeBag)
    }
    
    // MARK: - Private
    
    private var disposeBag = DisposeBag()
    
    // MARK: - Deinit
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}
