//  
//  LibsInitManager.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import IQKeyboardManager

class LibsInitManager {

	init() {
	}

}

extension LibsInitManager {

	func start() {
		initKeyboardManager()
	}

}

extension LibsInitManager {

	private func initKeyboardManager() {
		IQKeyboardManager.shared().isEnabled = true
	}

}
