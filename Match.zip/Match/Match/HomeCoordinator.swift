//  
//  HomeCoordinator.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

protocol HomeCoordinatorDelegate: AnyObject {
	func dettach(_ coordinator: HomeCoordinator)
}


class HomeCoordinator: CoordinatorType {

	weak var delegate: HomeCoordinatorDelegate?

    var childCoordinators: [CoordinatorType] = []
	var modalSource: UIViewController
    
    var navigationVc: UINavigationController!
    
	init(modalSource: UIViewController) {
        self.modalSource = modalSource
    }
    
    func start() {
        let homeVc = HomeBuilder.build()
        homeVc.delegate = self
        
        self.navigationVc = UINavigationController(rootViewController: homeVc)
        navigationVc.setNavigationBarHidden(true, animated: false)
        
        self.modalSource.present(self.navigationVc, animated: true, completion: nil)
    }
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}

extension HomeCoordinator: HomeViewControllerDelegate {
    func presentMatch(_ vc: HomeViewController) {
        
    }
    
    func dismiss(_ vc: HomeViewController) {
        vc.dismiss(animated: true, completion: nil)
    }
}
