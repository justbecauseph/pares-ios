//  
//  CongratulationsViewController.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/14/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import UIKit
import MBProgressHUD
import RxCocoa
import RxSwift

protocol CongratulationsViewControllerDelegate: AnyObject {
    func dismiss(_ vc: CongratulationsViewController)
}

class CongratulationsViewController: UIViewController, CreatedFromNib, DisplaysProgress {
    
    weak var delegate: CongratulationsViewControllerDelegate?
    
    // MARK: - Outlets
    @IBOutlet weak var chatButton: UIButton!
    
    // MARK: - DisplaysProgress
    
    var viewForHUD: UIView {
        return self.view
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        initViewModel()
    }
    
    private func initViews() {
        
    }
    
    // MARK: - ViewModel
    
    var viewModel: CongratulationsViewModel!
    
    private func initViewModel() {
        bindInputs()
        bindOutputs()
    }
    
    private func bindInputs() {
        
    }
    
    private func bindOutputs() {
        
        viewModel
            .outputs
            .isProcessing
            .asDriver()
            .drive(onNext: { [unowned self] (isProcessing) in
                if isProcessing {
                    self.showProgress()
                } else {
                    self.hideProgress()
                }
            }).disposed(by: disposeBag)
        
        viewModel
            .outputs
            .errorMessage
            .asDriver()
            .filter { !$0.isEmpty }
            .drive(onNext: { [unowned self] (errorMessage) in
                self.showAlert(type: .error, title: nil, message: errorMessage)
            }).disposed(by: disposeBag)
        
    }
    
    @IBAction func didTapChattingButton(_ sender: Any) {
        self.showAlert(type: .warning, title: "Warning", message: "Oooops! this feature is not yet availble!")
    }
    // MARK: - Private
    
    private var disposeBag = DisposeBag()
    
    // MARK: - Deinit
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}
