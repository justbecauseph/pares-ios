//  
//  UIImageView+setImageAndCache.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import Kingfisher
import UIKit

extension UIImageView {

	func setImageAndCache(_ resource: Resource?) {
		guard let _resource = resource else { return }
		var kf = self.kf
		kf.indicatorType = IndicatorType.activity
		kf.setImage(with: _resource)
	}

}
