//  
//  FcmTokenAdderPlugin.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import Moya

class FcmTokenAdderPlugin: PluginType {

	private var keychain: KeychainServicing

	init(keychain: KeychainServicing) {
		self.keychain = keychain
	}

	func prepare(_ request: URLRequest, target: TargetType) -> URLRequest {
		var modifiedRequest = request
		if let fcmToken = keychain.fcmToken { modifiedRequest.addValue(fcmToken, forHTTPHeaderField: "X-Device-FCM-Token") }
		return modifiedRequest
	}

}
