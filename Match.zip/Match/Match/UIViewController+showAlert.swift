//  
//  UIViewController+showAlert.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {

	enum AlertType {

		case error
        case warning
		case message

		var title: String {
			switch self {
			case .error:
				return "Error"
            case .warning:
                return "Warning"
			case .message:
				return "{app-name}"
			}
		}

	}

	func showAlert(type: AlertType, title: String?, message: String?, okActionHandler: (() -> Void)? = nil) {
		let alertController = UIAlertController(title: title ?? type.title, message: message, preferredStyle: .alert)
		let okAction = UIAlertAction(title: "OK", style: .default, handler: { _ in okActionHandler?() })
		alertController.addAction(okAction)
		present(alertController, animated: true, completion: nil)
	}

}

