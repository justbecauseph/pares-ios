//  
//  DefaultsService.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

protocol DefaultsServicing: AnyObject {

	var hasInitializedFreshInstall: Bool { get set }

	var hasShownOnboarding: Bool { get set }

}

class DefaultsService: DefaultsServicing {

	private enum Keys: String {
		case hasInitializedFreshInstall
		case hasShownOnboarding
	}

	var hasInitializedFreshInstall: Bool {
		get {
			return internalDefaults.bool(forKey: Keys.hasInitializedFreshInstall.rawValue)
		}
		set {
			internalDefaults.set(newValue, forKey: Keys.hasInitializedFreshInstall.rawValue)
		}
	}

	var hasShownOnboarding: Bool {
		get {
			return internalDefaults.bool(forKey: Keys.hasShownOnboarding.rawValue)
		}
		set {
			internalDefaults.set(newValue, forKey: Keys.hasShownOnboarding.rawValue)
		}
	}
    
    // MARK: - Services
    //var someService: SomeServicing?
    
    init() {
    }
    
    // MARK: - Private
	private let internalDefaults = DefaultsService.internalDefaults

	private static let internalDefaults = UserDefaults(suiteName: Config.shared.namespace).expect("Unable to create a new user defaults for namespace: \(Config.shared.namespace)")
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}
