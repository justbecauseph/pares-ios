//  
//  OnboardingBuilder.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

class OnboardingBuilder {
    
    static func build() -> OnboardingViewController {
        let vc = OnboardingViewController.createFromNib()

		let viewModel: OnboardingViewModel = {
			let dependency = OnboardingViewModel.Dependency()
			return OnboardingViewModel(dependency: dependency)
		}()

		vc.viewModel = viewModel

        return vc
    }
    
}
