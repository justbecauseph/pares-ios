//  
//  String+trimmed.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation

extension String {

	var trimmed: String? {
		guard !trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
			return nil
		}
		return self
	}

}

