//  
//  CreatedFromNib.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import UIKit

protocol CreatedFromNib {

	static func createFromNib() -> Self

}

extension CreatedFromNib where Self: UIViewController {

	static func createFromNib() -> Self {
		let nibName = String(describing: self)
		return Self.init(nibName: nibName, bundle: nil)
	}

}

