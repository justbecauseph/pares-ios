//  
//  KeychainService.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import KeychainSwift

protocol KeychainServicing {
    
    var accessToken: String? { get set }

	var fcmToken: String? { get set }

    func clear()
    
}

class KeychainService: KeychainServicing {
    
    private enum Key: String {
        case accessToken
		case fcmToken
		case userModel
    }
    
    var accessToken: String? {
        get {
            return internalKeychain.get(Key.accessToken.rawValue)
        }
        set {
            guard newValue != nil else {
                internalKeychain.delete(Key.accessToken.rawValue)
                return
            }
            internalKeychain.set(newValue!, forKey: Key.accessToken.rawValue)
        }
    }

	var fcmToken: String? {
		get {
			return internalKeychain.get(Key.fcmToken.rawValue)
		}
		set {
			guard newValue != nil else {
				internalKeychain.delete(Key.fcmToken.rawValue)
				return
			}
			internalKeychain.set(newValue!, forKey: Key.fcmToken.rawValue)
		}
	}

    func clear() {
		internalKeychain.clear()
    }
    
    // MARK: - private
    private var internalKeychain = KeychainService.internalKeychain

    private static let internalKeychain: KeychainSwift = KeychainSwift(keyPrefix: Config.shared.namespace)

	deinit {
		print("--Deallocating \(self)")
	}
    
}
