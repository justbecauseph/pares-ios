//  
//  OnboardingViewController.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import UIKit
import MBProgressHUD
import RxCocoa
import RxSwift

protocol OnboardingViewControllerDelegate: AnyObject {
    func dismiss(_ vc: OnboardingViewController)
    func presentLandingVc(_ vc: OnboardingViewController)
}

class OnboardingViewController: UIViewController, CreatedFromNib, DisplaysProgress {
    
    weak var delegate: OnboardingViewControllerDelegate?
    
    // MARK: - Outlets
    @IBOutlet weak var pagesCollectionView: UICollectionView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var nextButton: UIButton!
    
    
    // MARK: - DisplaysProgress
    
    var viewForHUD: UIView {
        return self.view
    }
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        initViewModel()
    }
    
    private func initViews() {
        initPagesCollectionsView()
    }
    
    private func initPagesCollectionsView() {
        pageControl.numberOfPages = blurbs.count
        pagesCollectionView.register(OnboardingCollectionViewCell.self)
        (pagesCollectionView as UIScrollView).delegate = self
        pagesCollectionView.dataSource = self
        pagesCollectionView.isPagingEnabled = true
        _ = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(moveToNextPage), userInfo: nil, repeats: true)
        pagesCollectionView.showsHorizontalScrollIndicator = false    
        DispatchQueue.main.async {
            self.pagesCollectionView.collectionViewLayout = FullPageFlowLayout(frame: self.pagesCollectionView.frame)
        }
    }
    
    @objc func moveToNextPage() {
        
        let nextPage = currentPage + 1
        if nextPage > (blurbs.count - 1) {
            self.currentPage = 0
            pagesCollectionView.scrollToPage(currentPage)
            return
        }
        let newPage = min(nextPage, blurbs.count - 1)
        pagesCollectionView.scrollToPage(newPage)
    }
    
    // MARK: - ViewModel
    
    var viewModel: OnboardingViewModel!
    
    private func initViewModel() {
        bindInputs()
        bindOutputs()
        bindButtonActions()
    }
    
    private func bindInputs() {
        
    }
    
    private func bindOutputs() {
        
        viewModel
            .outputs
            .isProcessing
            .asDriver()
            .drive(onNext: { [unowned self] (isProcessing) in
                if isProcessing {
                    self.showProgress()
                } else {
                    self.hideProgress()
                }
            }).disposed(by: disposeBag)
        
        viewModel
            .outputs
            .errorMessage
            .asDriver()
            .filter { !$0.isEmpty }
            .drive(onNext: { [unowned self] (errorMessage) in
                self.showAlert(type: .error, title: nil, message: errorMessage)
            }).disposed(by: disposeBag)
        
    }
    
    private func bindButtonActions() {
        nextButton
            .rx
            .tap
            .subscribe(onNext: { [unowned self] _ in
                self.delegate?.presentLandingVc(self)
            }).disposed(by: disposeBag)
    }
    
    // MARK: - Private
    private var currentPage = 0 {
        didSet {
            pageControl.currentPage = currentPage
        }
    }
    
    private var blurbs = [
        (image: UIImage(named: "Onboarding/ic_onboarding_1"), details: "www.mansmith.net", subDesc: nil),
        (image: UIImage(named: "Onboarding/ic_onboarding_1"), details: "THINK", subDesc: "DIFFERENTLY"),
        (image: UIImage(named: "Onboarding/ic_onboarding_1"), details: "SEE THINGS", subDesc: "DIFFERENTLY"),
        (image: UIImage(named: "Onboarding/ic_onboarding_1"), details: "DO THINGS", subDesc: "DIFFERENTLY")
    ]

    private var disposeBag = DisposeBag()
    
    // MARK: - Deinit
    
    deinit {
        print("--Deallocating \(self)")
    }
    
}

//Extension for dataSource of the collectionView
extension OnboardingViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return blurbs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeue(OnboardingCollectionViewCell.self, for: indexPath)
        
        let data = blurbs[indexPath.item]
        
        if let image = data.image {
            cell.configure(image: image)
        }
        
        return cell                
    }
    
}


extension OnboardingViewController: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let rate = scrollView.contentOffset.x / scrollView.frame.size.width
        self.currentPage = Int(ceil(rate))
    }
    
}

//Extension for UICollectionView scroll
extension UICollectionView {
    
    func scrollToPage(_ page: Int) {
        self.scrollToItem(at: IndexPath(row: page, section: 0), at: .centeredHorizontally, animated: true)
    }
    
}

