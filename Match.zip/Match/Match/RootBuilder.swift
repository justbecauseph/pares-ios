//  
//  RootBuilder.swift
//  Sample7
//
//  Created by Mark D. Rufino on 05/30/2019.
//  Copyright © 2019 coreproc-inc. All rights reserved.
//

import Foundation

class RootBuilder {
    
    static func build() -> RootViewController {
        let vc = RootViewController.createFromNib()

		let viewModel: RootViewModel = {
			let dependency = RootViewModel.Dependency()
			return RootViewModel(dependency: dependency)
		}()

		vc.viewModel = viewModel

        return vc
    }
    
}
