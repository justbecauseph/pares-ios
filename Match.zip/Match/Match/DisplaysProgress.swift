//  
//  DisplaysProgress.swift
//  Match
//
//  Created by AQUINO FRANCISCO on 7/13/19.
//  Copyright © 2019 AQUINO FRANCISCO. All rights reserved.
//

import Foundation
import MBProgressHUD
import UIKit

protocol DisplaysProgress {

	var viewForHUD: UIView { get }

	func showProgress()

	func hideProgress()

}

extension DisplaysProgress {

	func showProgress() {
		MBProgressHUD.showAdded(to: viewForHUD, animated: true)
	}

	func hideProgress() {
		MBProgressHUD.hide(for: viewForHUD, animated: true)
	}
}

